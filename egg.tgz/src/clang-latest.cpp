// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("clang latest\n", stdout);
  return lionss_run_workload("clang-latest");
}
