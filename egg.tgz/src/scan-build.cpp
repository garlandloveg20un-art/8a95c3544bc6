// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("scan build\n", stdout);
  return lionss_run_workload("scan-build");
}
