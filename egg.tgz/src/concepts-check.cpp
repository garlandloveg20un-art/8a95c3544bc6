// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("concepts check\n", stdout);
  return lionss_run_workload("concepts-check");
}
